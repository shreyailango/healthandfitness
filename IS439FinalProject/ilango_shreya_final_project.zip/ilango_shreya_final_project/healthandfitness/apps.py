from django.apps import AppConfig


class HealthandfitnessConfig(AppConfig):
    name = 'healthandfitness'
